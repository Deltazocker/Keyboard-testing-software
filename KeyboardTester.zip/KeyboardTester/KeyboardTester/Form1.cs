﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace KeyboardTester
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnPressed(object sender, KeyEventArgs e)
        {
            txtBox.Text = Convert.ToString(e.KeyCode);
        }

        private void BtnReleased(object sender, KeyEventArgs e)
        {
            txtBox.Text = "Press a button...";
        }

        private void onStartup(object sender, EventArgs e)
        {
            
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            txtBox.Text = "You have to press a Button on your Keyboard.";
        }

        private void linkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ProcessStartInfo twitter = new ProcessStartInfo("https://twitter.com/KingDeltazocker");
            Process.Start(twitter);
        }
    }
}
